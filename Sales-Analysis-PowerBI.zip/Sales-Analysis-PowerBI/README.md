# Sales Analysis (Power BI)

**Author:** Su Wai  
**Tool:** Microsoft Power BI Desktop

## Overview
This repository contains an interactive Power BI report that analyzes sales performance across time, product, customer, and region. It highlights **Revenue**, **Profit**, **Average Order Value**, **YoY/MoM trends**, and **Top performers**.

## Preview
Add screenshots of your report pages here (PNG). Example path:
```
report/screenshots/overview.png
```

## Open the Report
- File: `report/Sales_Analysis_PowerBI.pbix`  
- Recommended alternative: export a lighter **template** (`.pbit`) to share without embedded data.

## Data Setup (edit to match your project)
If your report uses parameters, update them after opening the file:
- `DataFolderPath` → local folder for sample CSV/Excel files
- `ServerName`, `DatabaseName` → if your sources are SQL
- Credentials are **not** included in this repository.

Sample anonymized data can go into: `data/sample/`.

## Model & Logic (add details)
- Star schema: `FactSales` + `DimDate`, `DimProduct`, `DimCustomer`, `DimRegion`  
- DAX measures: place exports in `dax/measures.dax`  
- Power Query (M) scripts: place exports in `queries/power_query/`

## Refresh
1. Open the PBIX in Power BI Desktop  
2. Confirm parameter values and data paths  
3. Click **Refresh**

## Project Structure
```
report/
  Sales_Analysis_PowerBI.pbix
  screenshots/
data/
  sample/
dax/
  measures.dax        # (optional) export from DAX Studio/Tabular Editor
queries/
  power_query/        # (optional) export from Advanced Editor
docs/
  architecture.md     # (optional) describe data flow & assumptions
```

## Large Files
This repository includes a `.gitattributes` configured for **Git LFS** to track `.pbix`/`.pbit`.  
If you clone locally and plan to push updates, run:
```
git lfs install
git lfs track "*.pbix" "*.pbit"
```

## License
Choose a license if you want others to reuse your work (MIT/Apache-2.0).

---

### How to publish this repo (website method)
1. Go to GitHub → **New** repository → Name: `Sales-Analysis-PowerBI` → Add README → Create  
2. Click **Add file ▸ Upload files** and upload everything from this folder  
3. Commit changes

### How to publish with GitHub Desktop (recommended for large PBIX)
1. Install GitHub Desktop and sign in  
2. **File ▸ New repository** → Name: `Sales-Analysis-PowerBI` → Create  
3. Copy these folders/files into that repo folder  
4. Commit → Publish repository  
5. If prompted, allow **Git LFS** for `.pbix`

---

> Tip: Pin this repo on your profile so recruiters can see it easily.
# Use: bash push.sh
# Edit <your-username> if needed and make sure the remote URL is correct before running.

git lfs install
git lfs track "*.pbix" "*.pbit"

git init
git add .gitattributes .gitignore README.md report data dax queries docs
git commit -m "Initial commit: Power BI Sales Analysis"

# Create repo on GitHub first, then set the remote URL below:
git branch -M main
git remote add origin https://github.com/<your-username>/Sales-Analysis-PowerBI.git
git push -u origin main